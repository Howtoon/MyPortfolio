/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanced_project_3;

import java.util.Scanner;

/**
 *
 * @author Howtoon
 */
public class GameController 
{
    private final Player player1;
    private final Player player2;
    private final Scanner kb = new Scanner(System.in);
    private final Maze maze;
    private boolean foundOrb = false;
    
    public GameController(Maze maze, Player player1, Player player2)
    {
        this.maze = maze;
        this.player1 = player1;
        this.player2 = player2;
        this.maze.displayRoom(player2);
         
    }
    
    public void playGame()
    {
        boolean gameIsNotOver = true;
        while(gameIsNotOver)
        {
            maze.displayRoom(player1);
            this.getNextMove();
            if (this.foundOrb)
            {
                gameIsNotOver = false;
                System.out.println("You have found the Orb! You Win!");
            }
            this.computerMove(player2);
            if (this.roomHasOrb(player2))
            {
                gameIsNotOver = false;
                System.out.println("The other player has found the Orb! You Lose!");
            }
        }
    }
    
    public void getNextMove()
    {
        boolean cannotMove = true;
        do
        {
            int direction;
            System.out.println("What is your next Move?");
            System.out.println("Up, Down, Left, Right, ORB: ");
            String input = kb.nextLine();
            if (input.compareToIgnoreCase("up") == 0)
            {
                direction = 0;
                if (this.maze.canMove(player1, direction))
                {
                    return;
                }
            }
            else if (input.compareToIgnoreCase("down") == 0)
            {
                direction = 1;
                if (this.maze.canMove(player1, direction))
                {
                    return;
                }
            }  
            else if (input.compareToIgnoreCase("left") == 0)
            {
                direction = 2;
                if (this.maze.canMove(player1, direction))
                {
                    return;
                }
            }
            else if (input.compareToIgnoreCase("right") == 0)
            {
                direction = 3;
                if (this.maze.canMove(player1, direction))
                {
                    return;
                }
            }
            else if (input.compareToIgnoreCase("orb") == 0)
            {
                if(this.roomHasOrb(player1))
                {
                    this.foundOrb = true;
                    return;
                }
                cannotMove = true;
            }
        }
        while (cannotMove);
    }
    
    public boolean roomHasOrb(Player player)
    {
        return player.getPlayerPosition().getOrb();
    }
    
    public void computerMove(Player player)
    {
        int direction;
        do
        {
            direction = maze.randInt(0, 3);
        }
        while(!this.maze.canMove(player, direction));
    }
}

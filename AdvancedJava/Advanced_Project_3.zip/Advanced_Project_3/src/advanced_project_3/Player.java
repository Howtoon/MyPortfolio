/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanced_project_3;

/**
 *
 * @author Howtoon
 */
public class Player
{
    private Room playerPosition;
    private final String name;
    
    public Player(Room playerPosition, String name)
    {
        this.playerPosition = playerPosition;
        this.playerPosition.playerEntered(this);
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
    public Room getPlayerPosition() {
        return playerPosition;
    }

    public void setPlayerPosition(Room playerPosition) {
        this.playerPosition = playerPosition;
        
    }
}

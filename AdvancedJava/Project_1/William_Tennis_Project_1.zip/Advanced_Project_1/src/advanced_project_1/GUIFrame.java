/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanced_project_1;
import javax.swing.JFrame;

/**
 *
 * @author wwt1
 */
public class GUIFrame extends JFrame
{    
    public GUIFrame()
    {
        this.setTitle("Contact List Array");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1024,1024);
    }
}
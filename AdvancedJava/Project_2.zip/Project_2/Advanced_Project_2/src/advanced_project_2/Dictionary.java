/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanced_project_2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Howtoon
 */
public class Dictionary
{
    Trie dictionary;
    String filename;
    int wordCount = 0;
    String[] allWords;
    public void readFile(String fileNAME)
    {
        dictionary = new Trie();
        filename = fileNAME;
        countWords();
        allWords = new String[wordCount];
        try 
        {
            File file = new File(filename);
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            int j=0;
            while ((line = bufferedReader.readLine()) != null) 
            {   
                boolean isWord = true;
                if (line.length()<4)
                {
                    isWord = false;
                    continue;
                }

                for (int i = 0; i<line.length(); i++)
                {
                    if (line.charAt(i)-'a'<0 || line.charAt(i)-'a'>25)
                    {
                        isWord = false;
                        break;
                    }
                }
                if (!isWord)
                {
                    continue;
                }
                this.dictionary.insert(line);
                allWords[j] = line;
                j++;
            }
            fileReader.close();
        } catch (IOException e) {
                e.printStackTrace();
        }
    }
    public void countWords()
    {
        try
        {
            File file = new File(filename);
            try (FileReader fileReader = new FileReader(file)) {
                BufferedReader bufferedReader = new BufferedReader(fileReader);
                String line;
                while ((line = bufferedReader.readLine()) != null)
                {
                    boolean isWord = true;
                    if (line.length()<4)
                    {
                        continue;
                    }
                    
                    for (int i = 0; i<line.length(); i++)
                    {
                        if (line.charAt(i)-'a'<0 || line.charAt(i)-'a'>25)
                        {
                            isWord = false;
                            break;
                        }
                    }
                    if (!isWord)
                    {
                        continue;
                    }
                    wordCount += 1;
                }
            }
        } 
        catch (IOException e) 
        {
        } 
    }
}

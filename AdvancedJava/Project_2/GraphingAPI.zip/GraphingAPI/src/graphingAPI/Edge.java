/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphingAPI;

/**
 *
 * @author Howtoon
 */
public class Edge {
	
    private final int fromVertexIndex;
    private final String fromVertexName;
    private final int toVertexIndex;
    private final String toVertexName;
    private final int length;

    public int getFromNodeIndex() 
    {
        return fromVertexIndex;
    }

    public String getFromNodeName()
    {
        return fromVertexName;
    }

    public int getToNodeIndex() 
    {
        return toVertexIndex;
    }  

    public String getToNodeName()
    {
        return toVertexName;
    }    

    public int getLength() 
    {
        return length;
    }

    public Edge(String fromNodeName, int fromNodeIndex, String toNodeName, int toNodeIndex, int length) 
    {
        this.fromVertexIndex = fromNodeIndex;
        this.fromVertexName = fromNodeName;
        this.toVertexIndex = toNodeIndex;
        this.toVertexName = toNodeName;
        this.length = length;
    }

    /**
     * Determines the neighboring node of a supplied node, based on the 2 nodes connected by this edge.
     * 
     * @param nodeIndex The index of one of the nodes that this edge joins.
     * @return The index of the neighboring node.
     *
     */
    public int getNeighbourIndex(int nodeIndex) 
    {
        if (this.fromVertexIndex == nodeIndex) 
        {
            return this.toVertexIndex;
        } else 
        {
            return this.fromVertexIndex;
        }
    }
			
}

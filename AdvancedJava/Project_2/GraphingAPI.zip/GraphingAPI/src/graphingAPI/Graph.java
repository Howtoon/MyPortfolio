/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphingAPI;

import java.util.ArrayList;
/**
 *
 * @author Howtoon
 */
public class Graph
{
    private final Vertex[] vertices;
    private final int noOfNodes;
    private final Edge[] edges;
    private final int noOfEdges;

    public Vertex[] getNodes() 
    {
        return vertices;
    }

    public int getNoOfNodes() 
    {
        return noOfNodes;
    }

    public Edge[] getEdges() 
    {
        return edges;
    }

    public int getNoOfEdges() 
    {
        return noOfEdges;
    }

    private final int layoverTime;

    /**
     * Constructor that builds the whole graph from an Array of Edges
     * @param edges
     * @param layoverTime
     */
    public Graph(Edge[] edges, int layoverTime)
    {
        this.edges = edges;
        this.layoverTime = layoverTime;
        this.noOfNodes = calculateNoOfNodes(edges);
        this.vertices = new Vertex[this.noOfNodes];
        for (int n = 0; n < this.noOfNodes; n++) 
        {
            this.vertices[n] = new Vertex();
        }
        this.noOfEdges = edges.length;
        for (int edgeToAdd = 0; edgeToAdd < this.noOfEdges; edgeToAdd++) 
        {
            this.vertices[edges[edgeToAdd].getFromNodeIndex()].getEdges().add(edges[edgeToAdd]);
            this.vertices[edges[edgeToAdd].getFromNodeIndex()].setName(edges[edgeToAdd].getFromNodeName());
            this.vertices[edges[edgeToAdd].getToNodeIndex()].getEdges().add(edges[edgeToAdd]);
            this.vertices[edges[edgeToAdd].getToNodeIndex()].setName(edges[edgeToAdd].getToNodeName());
        }

    }

    /**
     * Calculate the number of nodes in an array of edges
     * 
     * @param edges An array of edges that represents the graph.
     * @return The number of nodes in the graph.
     *
     */
    private int calculateNoOfNodes(Edge[] edges) 
    {
        int noOfNodes = 0;
        for (Edge e:edges ) 
        {
            if (e.getToNodeIndex() > noOfNodes) noOfNodes = e.getToNodeIndex();
            if (e.getFromNodeIndex() > noOfNodes) noOfNodes = e.getFromNodeIndex();
        }
        noOfNodes++;	
        return noOfNodes;		
    }

    /**
     * Uses Dijkstra's algorithm to calculate the shortest distance from the source to all nodes
     * 
     */
    public void calculateShortestDistances() 
    {
        this.vertices[0].setDistanceFromSource(0);
        int nextNode = 0;

        for (int i = 0; i < this.vertices.length; i++) 
        {

            ArrayList<Edge> currentNodeEdges = this.vertices[nextNode].getEdges();
            for (int joinedEdge = 0; joinedEdge < currentNodeEdges.size(); joinedEdge++) 
            {

                int neighbourIndex = currentNodeEdges.get(joinedEdge).getNeighbourIndex(nextNode);

                if (!this.vertices[neighbourIndex].isVisited()) 
                {

                    int tentative = this.vertices[nextNode].getDistanceFromSource() + currentNodeEdges.get(joinedEdge).getLength();

                    if (tentative < vertices[neighbourIndex].getDistanceFromSource()) 
                    {
                            vertices[neighbourIndex].setDistanceFromSource(tentative);
                    }
                }
            }
            vertices[nextNode].setVisited(true);
            nextNode = getNodeShortestDistanced();
        }

    }

    /**
     * Scans the unvisited nodes and calculates which one has the shortest distance from the source.
     * 
     * @return The index of the node with the smallest distance
     */
    private int getNodeShortestDistanced() 
    {

        int storedNodeIndex = 0;
        int storedDist = Integer.MAX_VALUE;

        for (int i = 0; i < this.vertices.length; i++) 
        {
            int currentDist = this.vertices[i].getDistanceFromSource();			
            if (!this.vertices[i].isVisited() && currentDist < storedDist) 
            {
                storedDist = currentDist;
                storedNodeIndex = i;
            }

        }

        return storedNodeIndex;
    }

    /**
     * Overrides Object.toString() to show the contents of the graph
     * 
     * @return 
     */
    @Override
    public String toString() 
    {
        String output = "Number of nodes = " + this.noOfNodes;
        output += "\nNumber of edges = " + this.noOfEdges;
        for (int i = 0; i < this.vertices.length; i++) 
        {
            output += ("\nThe shortest distance from "+this.vertices[0].getName()+ " to " + this.vertices[i].getName() + " is " + vertices[i].getDistanceFromSource());
        }
        return output;
    }
}
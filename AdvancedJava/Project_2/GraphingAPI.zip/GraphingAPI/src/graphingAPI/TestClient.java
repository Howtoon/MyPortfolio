/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphingAPI;

/**
 *
 * @author Howtoon
 */

public class TestClient {
    public static void main(String[] args) 
    {
        Edge[] edges =
        {	
            new Edge("Chicago", 0, "Miami", 2, 1),
            new Edge("Chicago", 0, "Los Angeles", 3, 4),
            new Edge("Chicago", 0, "Las Vegas", 4, 2),
            new Edge("Chicago", 0, "New York", 1, 3),
            new Edge("New York", 1, "Los Angeles", 3, 2),
            new Edge("New York", 1, "Las Vegas", 4, 3),
            new Edge("New York", 1, "Pensacola", 5, 1),
            new Edge("Miami", 2, "Las Vegas",4, 1),
            new Edge("Los Angeles", 3, "Pensacola", 5, 4),
            new Edge("Las Vegas", 4,"Pensacola", 5, 2),
            new Edge("Las Vegas", 4,"Richmond", 6, 7),
            new Edge("Las Vegas", 4,"Destin", 7, 2),
            new Edge("Pensacola", 5, "Richmond", 6, 4),
            new Edge("Richmond", 6, "Destin",7, 5)
        };
        Graph graph = new Graph(edges, 30);
        graph.calculateShortestDistances();
        System.out.println(graph.toString());
    }
}

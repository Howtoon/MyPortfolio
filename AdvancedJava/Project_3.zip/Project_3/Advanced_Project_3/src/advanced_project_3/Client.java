/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanced_project_3;

/**
 *
 * @author Howtoon
 */
public class Client 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        final Maze maze = new Maze();
        Room room = maze.getRandomRoom();
        final Player player1 = new Player(room, "U");
        room = maze.getRandomRoom();
        final Player player2 = new Player(room, "C");
        final GameController controller = new GameController(maze, player1, player2);
        controller.playGame();
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package advanced_project_3;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Howtoon
 */
public class Maze 
{
    private int sizeOfGrid;
    private Room[][] maze;

    public Maze()
    {
        createMaze();
        placeOrb();
    }
    
    private void createMaze()
    {
        this.sizeOfGrid = this.randInt(3, 5);
        this.maze = new Room[this.sizeOfGrid][this.sizeOfGrid];
        int roomNumber = 1;
        for(int i=0 ; i<this.sizeOfGrid ; i++)  //xPos
        {
            for (int j=0 ; j<this.sizeOfGrid ; j++) //yPos
            {
                int doors;
                if (i==0 || i==this.sizeOfGrid-1 || j==0 || j==this.sizeOfGrid-1)
                {
                    do 
                    {
                        doors  = this.randInt(7, 15);
                        if (doors==7 || doors==11 || doors==13 || doors==14 || doors==15)
                        {
                            break;
                        }
                    }
                    while(true);
                }
                else
                {
                    do 
                    {
                        doors  = this.randInt(1, 15);
                        if (doors==7 || doors==11 || doors==13 || doors==14 || doors==15)
                        {
                            break;
                        }
                    }
                    while(true);
                }
                this.maze[i][j] = new Room(roomNumber, doors, this.sizeOfGrid , i, j);
                roomNumber++;
            }
        }
    }
    
    private void placeOrb()
    {
        maze[this.randInt(0, this.sizeOfGrid-1)][this.randInt(0, this.sizeOfGrid-1)].setOrb(true);
    }
    
    public boolean canMove(Player player, int direction)
    {
        Room playerPosition = player.getPlayerPosition();
        switch (direction) {
            case 0:
                if (playerPosition.getUp())
                {
                    player.getPlayerPosition().playerExit(player);
                    player.setPlayerPosition(maze[playerPosition.getxPos()][playerPosition.getyPos()+1]);
                    player.getPlayerPosition().playerEntered(player);
                    return true;
                }   break;
            case 1:
                if (playerPosition.getDown())
                {
                    player.getPlayerPosition().playerExit(player);
                    player.setPlayerPosition(maze[playerPosition.getxPos()][playerPosition.getyPos()-1]);
                    player.getPlayerPosition().playerEntered(player);
                    return true;
                }   break;
            case 2:
                if (playerPosition.getLeft())
                {
                    player.getPlayerPosition().playerExit(player);
                    player.setPlayerPosition(maze[playerPosition.getxPos()-1][playerPosition.getyPos()]);
                    player.getPlayerPosition().playerEntered(player);
                    return true;
                }   break;
            case 3:
                if (playerPosition.getRight())
                {
                    player.getPlayerPosition().playerExit(player);
                    player.setPlayerPosition(maze[playerPosition.getxPos()+1][playerPosition.getyPos()]);
                    player.getPlayerPosition().playerEntered(player);
                    return true;
                }   break;
            default:
                break;
        }
        return false;
    }
    
    public void displayRoom(Player player)
    {
        ArrayList<Player> occupants = player.getPlayerPosition().getPlayers();
        if (player.getName().compareToIgnoreCase("c")==0)
        {
            return;
        }
        Room position = player.getPlayerPosition();
        System.out.println("\n\nRoom: "+position.getRoomNumber());
        //System.out.println("Player: "+player.getName());
        //System.out.println("Orb: "+position.getOrb());
        System.out.print("+--");
        if (position.getUp())
        {
            System.out.print("##");
        }
        else
        {
            System.out.print("--");
        }
        System.out.println("--+");
        System.out.println("|      |");
        System.out.print("|  ");
        for (int i = 0; occupants.size()-1 >= i;i++)
        {
            System.out.print(occupants.get(i).getName());
        }
        if (occupants.size()==1)
        {
            System.out.print(" ");
        }
        System.out.println("  |");
        System.out.print("| ");
        if (position.getOrb())
        {
            System.out.println("O    |");
        }
        else
        {
            System.out.println("     |"); 
        }
        if (position.getLeft())
        {
            System.out.print("#      ");
        }
        else
        {
            System.out.print("|      ");
        }
        if (position.getRight())
        {
            System.out.println("#");
        }
        else
        {
            System.out.println("|");
        }
        if (position.getLeft())
        {
            System.out.print("#      ");
        }
        else
        {
            System.out.print("|      ");
        }
        if (position.getRight())
        {
            System.out.println("#");
        }
        else
        {
            System.out.println("|");
        }
        System.out.println("|      |");
        System.out.println("|      |");
        System.out.print("+--");
        if (position.getDown())
        {
            System.out.print("##");
        }
        else
        {
            System.out.print("--");
        }
        System.out.println("--+");
    }
    
    public int randInt(int min, int max) 
    {
        Random rand = new Random();
        int randomNum = rand.nextInt((max - min) + 1) + min;
        return randomNum;
    }
    
    public Room getRandomRoom()
    {
        Room room;
        boolean placedPlayer = false;
        do
        {
            int xPos = this.randInt(0, sizeOfGrid-1);
            int yPos = this.randInt(0, sizeOfGrid-1);
            room = this.maze[xPos][yPos];
            if (!room.getOrb() && !room.roomIsOccupied() && (room.getUp() || room.getDown() || room.getLeft() || room.getRight()))
            {
                placedPlayer = true;
            }
        }
        while (!placedPlayer);
        
        return room;
    }
}

#include <stdio.h>
#include <stdlib.h>

#include "scanner.h"

//example of using the functions in scanner
int main(int argc, char **argv)
{
    int value1;
    int value2;
    FILE *fp = fopen(argv[1], "r");

    value1 = readInt(fp); //perform first reads
    value2 = readInt(fp);
    while(!feof(fp)){
        /*Do what you want with read in values here*/
	int result = value1 + value2;
        printf("%d\n", result);
        
	//free(string); //dynamically allocated memory must be freed
        value1 = readInt(fp);
        value2 = readInt(fp);
    }
    fclose(fp); //do not forget to close the file when finished with it
    return 0;
}

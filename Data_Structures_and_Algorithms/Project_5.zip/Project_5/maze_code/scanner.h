#ifndef SCANNER_H
#define SCANNER_H

#include <stdio.h>
#include <stdlib.h>

int readInt(FILE *);
char *readString(FILE *);
#endif

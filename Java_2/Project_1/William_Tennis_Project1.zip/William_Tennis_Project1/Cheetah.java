/**
Name:William Tennis
Date: 01/11/2016
Project 1
*/

public class Cheetah
{
   private String country;
   private double speed;
   
   public void Cheetah()
   {
   return;
   }
   
   public void setCountry(String a)
   {
   country=a;
   return;
   }
   
   public void setSpeed(double a)
   {
   speed=a;
   return;
   }
   
   public String getCountry()
   {
   return country;
   } 
   
   public double getSpeed()
   {
   return speed;
   }
}
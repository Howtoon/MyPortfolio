/**
Name:William Tennis
Date: 01/11/2016
Project 1
*/

import java.util.Scanner;

public class Tester
{
   public static void main (String[] args)
   {
   System.out.println("Programmed by William Tennis\n");
   Cheetah cat1= new Cheetah();
   cat1.setCountry("Sudan");
   System.out.println("Country: "+cat1.getCountry());
   cat1.setSpeed(72);
   System.out.println("Speed: "+cat1.getSpeed());
   return;
   }
}


public interface MovingAnimalInterface{
   public void move();
}